package lpp.projetofinal;

public interface Interface {
    
    public int calcularSalario();
}
